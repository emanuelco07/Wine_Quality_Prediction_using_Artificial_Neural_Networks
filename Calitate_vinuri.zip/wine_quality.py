import pandas as pd
import os
import numpy as np
from sklearn import metrics
from keras import layers
from scipy.stats import zscore
from keras.callbacks import EarlyStopping
from keras.callbacks import ModelCheckpoint
from sklearn.model_selection import KFold
from keras.models import Sequential
from keras.layers import Dense, Activation
import matplotlib.pyplot as plt

path = "./data/"
filename_read = os.path.join(path,"winequality-red.csv")
filename_write = os.path.join(path,"winequality-red-out-of-sample.csv")
df = pd.read_csv(filename_read, sep =";") #nu avem valori lipsa, daca aveam, puneam al doilea parametru - na_values=['NA','?']
# punem separatorul ; deoarece asa sunt separate datele in fisier

# Shuffle
np.random.seed(42)
df = df.reindex(np.random.permutation(df.index))
df.reset_index(inplace=True, drop=True)

#nu avem string uri si nici valori nule
# Preprocess
# def missing_median(df, name):
#     med = df[name].median()
#     df[name] = df[name].fillna(med)
# cars = df['car name']
# df.drop('car name',axis=1,inplace=True)
# missing_median(df, 'horsepower')

dataset=df.values
x=dataset[:, 0:11]
y=dataset[:, 11]

# Cross-Validate
kf = KFold(10)
    
oos_y = []
oos_pred = []
fold = 0
for train, test in kf.split(x):
    fold+=1
    print("Fold #{}".format(fold))
        
    x_train = x[train]
    y_train = y[train]
    x_test = x[test]
    y_test = y[test]
    
    model = Sequential()
    model.add(layers.Input(shape=(x_train.shape[1],)))
    model.add(layers.Dense(30, activation='relu'))         # Stratul ascuns 1
    model.add(layers.Dense(35, activation='relu'))         # Stratul ascuns 2
    model.add(layers.Dense(30, activation='relu'))         # Stratul ascuns 3
    model.add(layers.Dense(1))     
    model.compile(loss='mean_squared_error', optimizer='adam')
    
    monitor = EarlyStopping(monitor='val_loss', min_delta=1e-3, patience=5, verbose=1, mode='auto')
    model.fit(x_train,y_train,validation_data=(x_test,y_test),callbacks=[monitor],verbose=1,epochs=100)
    
    pred = model.predict(x_test)
    
    oos_y.append(y_test)
    oos_pred.append(pred)        

    # Measure this fold's RMSE
    score = np.sqrt(metrics.mean_squared_error(pred,y_test))
    print("Fold score (RMSE): {}".format(score))

# Build the oos prediction list and calculate the error.
oos_y = np.concatenate(oos_y)
oos_pred = np.concatenate(oos_pred)
score = np.sqrt(metrics.mean_squared_error(oos_pred,oos_y))
print("Final, out of sample score (RMSE): {}".format(score))    
    
# Write the cross-validated prediction
oos_y = pd.DataFrame(oos_y)
oos_pred = pd.DataFrame(oos_pred)
oosDF = pd.concat( [df, oos_y, oos_pred],axis=1 )
oosDF.to_csv(filename_write,index=False)

print(oosDF)

# Regression chart.
def chart_regression(pred, y, sort=True):
    t = pd.DataFrame({'pred': pred, 'y': y.flatten()})
    if sort:
        t.sort_values(by=['y'], inplace=True)
    plt.plot(t['y'].tolist(), label='expected')
    plt.plot(t['pred'].tolist(), label='prediction')
    plt.ylabel('output')
    plt.legend()
    plt.show()


# Plot the chart
chart_regression(pred.flatten(),y_test)

# RNA5r